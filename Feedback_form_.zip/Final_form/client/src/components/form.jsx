import React, { useState } from 'react'
import Alert from 'react-bootstrap/Alert';
//<form action="https://formspree.io/f/xaygpbnv" method="POST"></form>
const Form = () => {

  const [show, setShow] = useState(false);
  const [email,setEmail] = useState("");
   //console.log(email);


   const sendEmail = async(e)=>{
    e.preventDefault();

    const res = await fetch("/register",{
      method: "POST",
      headers:{
        "Content-Type":"application/json"
      },
      body: JSON.stringify({
        email
      })
    });

    const data = await res.json();
        console.log(data);

        if (data.status === 401 || !data) {
            console.log("error")
        } else {
            setShow(true);
            setEmail("")
            console.log("Email sent")
        }
    }
     
    
  return (
    <>
    {
      show ? <Alert variant="primary" onClose={() => setShow(false)} dismissible>
          Your Email Sent Succesfully..! Now click on Submit button.
      </Alert> : ""
  }
    <form action="https://formspree.io/f/xaygpbnv" method="POST">
    <h1>Contact <span>Here</span></h1>
    <input 
    type="text" 
    name="name" 
    id="" 
    placeholder='Enter name'/> 

    <input 
    type="email" 
    name="email" 
    onChange={(e)=>setEmail(e.target.value)}   
    id="" 
    placeholder='Enter email'/> 

    <input 
    type="phone" 
    name="phone" 
    id="" 
    placeholder='+91'/>

    <textarea 
    name="message" 
    id="" cols="30" rows="10" 
    placeholder='Type here...'/>

    <br />
    <button type="submit" onClick={sendEmail}>Confirm</button> 
    <br />
    <br />
    <button type="submit">Submit</button>
      
    </form>
    </>
  )
}

export default Form