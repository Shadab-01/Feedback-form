import Form from "./components/form";
import 'bootstrap/dist/css/bootstrap.min.css';
function App() {
  return (
 <>
 <Form/>
 </>
  );
}

export default App;
